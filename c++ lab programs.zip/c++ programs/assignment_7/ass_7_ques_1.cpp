#include<iostream>
using namespace std;

template<class T>
T find_largest(T a,T b,T c)
{
	T max=(a>b)?((a>c)?a:c):((b>c)?b:c);
	return max;
}
int main()
{
	int a,b,c;
	cout<<"Enter three integers numbers"<<endl;
	cin>>a>>b>>c;
	cout<<"largest number is " <<find_largest(a,b,c)<<endl;
	
	float x,y,z;
	cout<<"Enter three float numbers"<<endl;
	cin>>x>>y>>z;
	cout<<"largest number is " <<find_largest(x,y,z);
	return 0;
}
