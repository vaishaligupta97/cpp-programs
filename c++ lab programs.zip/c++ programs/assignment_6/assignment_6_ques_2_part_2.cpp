#include<iostream>
using namespace std;
const int SIZE=3;
class queue
{
	private:
		int a[SIZE];
		int r,f;
	public:
		
		queue()
		{
			r=f=-1;
		}
		void insert(int val)
		{
			if(r==SIZE-1)
			{
				throw f;
			}
			if(r=-1)
			{
				f=r=0;
			}
			else
			{
				r=r+1;
			}
			a[r]=val;
		}
		int del()
		{
			if(f==-1)
			{
				throw r;
			}
			if(r==f)
			{
				r=f=0;
			}
			else
				f=f+1;
			int val=a[f];
			return val;
		}
};
int main()
{
	queue q;
	try
	{
		q.insert(10);
		q.insert(40);
		q.insert(60);
		q.insert(70);
		q.del();
		q.del();
		q.del();
		q.del();
	}
	catch(int x)
	{
		cout<<"queue is full"<<endl;
	}
	catch(int y)
	{
		cout<<"queue is empty"<<endl;
	}
	return 0;
}

