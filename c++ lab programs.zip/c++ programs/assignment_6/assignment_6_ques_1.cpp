#include<iostream>
using namespace std;

class integer
{
	private:
		int num1,num2;
	public:
		class check
		{ };
		class zero
		{
		};
		
		bool digit(int num)
		{
			while(num>0)
			{
				int d=num%10;
				if(d<0 || d>9 || "a-z"||"A-Z")
					return false;
				num=num/10;
			}
			return true;
		}
		void type()
		{
			cout<<"Enter num1"<<endl;
			cin>>num1;
			if(digit(num1)!=false)
			{
				throw check();
			}
	
			cout<<"Enter num2"<<endl;
			cin>>num2;
			if(digit(num2)!=false)
			{
				throw check();
				
			}
		}
		float div()
		{
			if(num2==0)
			{
				throw zero();
			}	
			float ans=float(num1)/float(num2);
			cout<<ans;
		}
};
int main()
{
	integer obj;
	try
	{
		obj.type();
	//	obj.div();
	}
	catch(integer::check)
	{
		cout<<"wrong type of data is entered"<<endl;
	}
	try
	{
		obj.div();
	}
	catch(integer::zero)
	{
		cout<<"Divide by zero "<<endl;
	}
}
