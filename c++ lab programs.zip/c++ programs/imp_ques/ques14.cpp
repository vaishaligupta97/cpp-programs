#include<iostream>
using namespace std;
int main()
{
	int n;
	do
	{
		cout<<"enter a number"<<endl;
		cin>>n;
		unsigned long fact=1;
		for(int i=n;i>0;i--)
		{
			fact=fact*i;
		}
		cout<<"factorial= "<<fact<<endl;
	}while(n!=0);
	return 0;
}
