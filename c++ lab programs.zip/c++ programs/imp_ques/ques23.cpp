#include<iostream>
using namespace std;

struct date
{
	int day,mon,year;
};

enum etype{labourer,secretry,manager,accountant,executive,resercher};
struct employee
{
	int emp_no;
	float salary;
	date d;
	etype e;
};

int main()
{
	employee emp[3];
	for(int i=1;i<=3;i++)
	{
		cin>>emp[i].emp_no>>emp[i].salary>>emp[i].d.day>>emp[i].d.mon>>emp[i].d.year>>emp[i].e;
	}
	cout<<"entered employee information"<<endl;
	cout<<"id"<<"\t"<<"salary"<<"\t"<<"day"<<"\t"<<"month"<<"\t"<<"year"<<"\t"<<"emp_type"<<endl;
	for(int i=1;i<=3;i++)
	{
		cout<<emp[i].emp_no<<"\t"<<emp[i].salary<<"\t"<<emp[i].d.day<<"\t"
		<<emp[i].d.mon<<"\t"<<emp[i].d.year<<"\t"<<emp[i].e<<endl;
	}
}
