#include<iostream>
#include<ctype.h>
using namespace std;
int main()
{
	char ch;
	cout<<"Enter a character\n";
	cin>>ch;
	int a=islower(ch);
	cout<<a;
	return 0;
}
