#include<iostream>
using namespace std;

void zerosmaller(int&,int&);

int main()
{
	int num1,num2;
	cout<<"enter num1 and num2"<<endl;
	cin>>num1>>num2;
	zerosmaller(num1,num2);
	cout<<"num1= "<<num1<<endl<<"num2= "<<num2<<endl;
	return 0;
}
void zerosmaller(int& n1,int& n2)
{
	if(n1<n2)
		n1=0;
	else
		n2=0;
}
