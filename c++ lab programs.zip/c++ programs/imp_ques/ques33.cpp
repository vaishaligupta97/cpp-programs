#include<iostream>
using namespace std;

struct time
{
	int hrs,min,sec;
};
long hms_to_sec(int hrs,int mins,int sec);

int main()
{
	time t1;long seconds;
	cout<<"enter the value of t1 in the format(12:59:59)"<<endl;
	cin>>t1.hrs>>t1.min>>t1.sec;
	seconds=hms_to_sec(t1.hrs,t1.min,t1.sec);
	cout<<"total seconds are "<<seconds<<endl;
	return 0;
}
long hms_to_sec(int hrs,int mins,int sec)
{
	return hrs*3600+mins*60+sec;
}
