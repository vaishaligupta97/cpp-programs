#include<iostream>
using namespace std;
int main()
{
	int n;
	cout<<"Enter the number of gallons"<<endl;
	cin>>n;
	float cubic_feet=n/7.481;
	cout<<"cubic_feet="<<cubic_feet<<endl;
	return 0;
}
