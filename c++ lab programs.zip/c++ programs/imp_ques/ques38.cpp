#include<iostream>
using namespace std;

void display();
int count=1;
int main()
{
	int i;
	for(i=1;i<=10;i++)
	{
		display();
	}
	return 0;
}
/*void display()
{
	int static count=1;
	cout<<"i have been called "<<count<<" times"<<endl;
	count++;
}*/
void display()
{
	cout<<"I have been called "<<count<<" times"<<endl;
	count++;
}
