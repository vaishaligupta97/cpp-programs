#include<iostream>
using namespace std;

struct fraction
{
	int num,deno;
};

fraction fadd(fraction,fraction);
fraction fsub(fraction,fraction);

int main()
{
	fraction f1,f2,f3_add,f3_sub;
	f1={3,4};
	cout<<"enter second fraction"<<endl;
	cin>>f2.num>>f2.deno;
	f3_add=fadd(f1,f2);
	cout<<"addition of two fraction "<<f3_add.num<<"/"<<f3_add.deno<<endl;
	f3_sub=fsub(f1,f2);
	cout<<"subtraction of two fraction "<<f3_sub.num<<"/"<<f3_sub.deno<<endl;
	return 0;
}
fraction fadd(fraction f1,fraction f2)
{
	fraction f3;
	f3.num=f1.num*f2.deno+f2.num*f1.deno;
	f3.deno=f1.deno*f2.deno;
	return f3;
}
fraction fsub(fraction f1,fraction f2)
{
	fraction f3;
	f3.num=f1.num*f2.deno-f2.num*f1.deno;
	f3.deno=f1.deno*f2.deno;
	return f3;
}
