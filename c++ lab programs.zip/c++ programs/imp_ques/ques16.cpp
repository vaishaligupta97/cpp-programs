#include<iostream>
using namespace std;
int main()
{
	int years;
	float rate,principal;
	cout<<"Enter the initial amount"<<endl;
	cin>>principal;
	cout<<"enter number of years"<<endl;
	cin>>years;
	cout<<"enter interest rate(percent per year)"<<endl;
	cin>>rate;
	float amount;
	for(int i=1;i<=years;i++)
	{
	//	cout<<"principal= "<<principal<<endl;
		amount=principal+principal*(rate/100);
	//	cout<<"amount after "<<i<<" year ="<<amount<<endl;
	//	cout<<endl;
		principal=amount;
	}
	cout<<"\nAt the end of "<<years<<" years, you will have= "<<amount<<endl;
	return 0;
}
