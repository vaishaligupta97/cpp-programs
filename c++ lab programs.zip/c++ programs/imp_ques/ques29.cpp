#include<iostream>
using namespace std;

float circarea(float);
int main()
{
	float a,radius;
	cout<<"enter radius"<<endl;
	cin>>radius;
	a=circarea(radius);
	cout<<"area of circle= "<<a<<endl;
	return 0;
}
float circarea(float r)
{
	float area;
	area=3.14*r*r;
	return area;
}
