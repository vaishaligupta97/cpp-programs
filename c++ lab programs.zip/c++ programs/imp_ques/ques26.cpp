#include<iostream>
using namespace std;

struct time
{
	int hrs,min,sec;
};

int main()
{
	time t1,t2,t3;char ch;
	cout<<"enter t1 value "<<endl;
	cin>>t1.hrs>>ch>>t1.min>>ch>>t1.sec;
	cout<<"enter t2 value"<<endl;
	cin>>t2.hrs>>ch>>t2.min>>ch>>t2.sec;
	if(t1.hrs>12 ||t1.min>59 ||t1.sec>59 ||t2.hrs>12 ||t2.min>59 ||t2.sec>59) 
	{
		cout<<"invalid value"<<endl;
	}
	else
	{
		long t1_total_sec=t1.hrs*3600+t1.min*60+t1.sec;
		long t2_total_sec=t2.hrs*3600+t2.min*60+t2.sec;
		long total_sec=t1_total_sec+t2_total_sec;
		t3.hrs=total_sec/3600;
		t3.min=(total_sec%3600)/60;
		t3.sec=(total_sec%3600)%60;
		cout<<"value of t3= "<<t3.hrs<<":"<<t3.min<<":"<<t3.sec<<endl;
		return 0;
	}
}
