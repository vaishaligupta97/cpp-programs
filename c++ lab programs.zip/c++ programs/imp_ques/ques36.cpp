#include<iostream>
using namespace std;

void swap(int&,int&);

int main()
{
	int a,b;
	cout<<"enter a and b"<<endl;
	cin>>a>>b;
	swap(a,b);
	cout<<"after swapping a nd b "<<endl<<"a is "<<a<<endl<<"b is "<<b<<endl;
	return 0;
}
void swap(int& x,int& y)
{
	int temp;
	temp=x;
	x=y;
	y=temp;
}
