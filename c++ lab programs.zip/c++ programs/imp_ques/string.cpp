#include<iostream>
#include<string.h>
using namespace std;

class strin
{
	private:
		char *str;
	public:
		strin()
		{
		}
		void getstring()
		{
			cout<<"Enter a string"<<endl;
			cin>>str;
		}
		void operator==(char s2)
		{
			if(strlen(*str)==strlen(*s2.str))
			{
				while(*str!='\0')
				{
					if(*str==*s2.str)
					{
						*str++;
						*s2.str++;
					}
				}
			}
		}
};
int main()
{
	strin s1,s2;
	s1.getstring();
	s2.getstring();
	if(s1==s2)
	{
		cout<<"Strings are equal"<<endl;
	}
	else
	{
		cout<<"Strings are not equal"<<endl;
	}
}
