#include<iostream>
using namespace std;
int main()
{
	int choice;char ch;
	float f,c;
	do{
	cout<<"choose your choice"<<endl;
	cout<<"Type1 to convert celcius to farenheit"<<endl;
	cout<<"Type2 to convert farenheit to celcius"<<endl;
	cin>>choice;
	switch(choice)
	{
		case 1:  cout<<"enter tempreature in farenheit"<<endl;
				cin>>f;
				c=5*(f-32)/9;
				cout<<"in celcius="<<c;
				break;
		case 2: cout<<"Enter tempreature in celcius"<<endl;
				cin>>c;
				f=9*c/5+32;
				cout<<"in farenheit="<<f;
				break;
		default: cout<<"Try again"<<endl;
	}
	cout<<"\nDo u want to continue(y/n)"<<endl;
	cin>>ch;
}while(ch!='n');
	return 0;
}
