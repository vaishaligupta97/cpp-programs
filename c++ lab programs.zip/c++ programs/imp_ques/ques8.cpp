#include<iostream>
using namespace std;
int main()
{
	int a,b,c,d;
	char ch;
	cout<<"enter first fraction"<<endl;
	cin>>a>>ch>>b;
	cout<<"enter second fraction"<<endl;
	cin>>c>>ch>>d;
	cout<<"sum is"<<a*d+b*c<<'/'<<b*d<<endl;
	return 0;
}
