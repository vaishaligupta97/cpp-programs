#include<iostream>
using namespace std;
int main()
{
	float c;
	cout<<"enter the tempreture in celcius"<<endl;
	cin>>c;
	float f=9*c/5+32;
	cout<<"tempreture in farenheit="<<f<<endl;
	return 0;
}
