#include<iostream>
using namespace std;
struct Distance
{
	int feet;
	float inches;
};
Distance compare(Distance d1,Distance d2);
void display(Distance);

int main()
{
	Distance d1,d2,d3;
	cout<<"enter distance d1"<<endl;
	cin>>d1.feet>>d1.inches;
	cout<<"enter distance d2"<<endl;
	cin>>d2.feet>>d2.inches;
	d3=compare(d1,d2);
	display(d3);
	return 0;
}
Distance compare(Distance d1,Distance d2)
{
	if(d1.feet>d2.feet)
		return d1;
	else
		return d2;
	if(d1.feet==d2.feet)
	{
		if(d1.inches>d2.inches)
			return d1;
		else
			return d2;
	}
}
void display(Distance d)
{
	cout<<"the greater distance is= "<<d.feet<<"-"<<d.inches<<endl;
}
