#include<iostream>
using namespace std;
int main()
{
	int n,i;
	cout<<"Enter a number"<<endl;
	cin>>n;
	int k=1;
	for(i=1;i<=20;i++)
	{
		for(int j=1;j<=10;j++,k++)
		{
			int pro=n*k;
			cout<<pro<<"\t";
		}
		cout<<endl;
	}
	return 0;
}
