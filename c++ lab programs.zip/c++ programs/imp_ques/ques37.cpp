#include<iostream>
using namespace std;

struct time
{
	int hrs,min,sec;
};

void swap(time&,time&);

int main()
{
	time t1,t2;
	t1={2,56,49};
	cout<<"enter t2 value"<<endl;
	cin>>t2.hrs>>t2.min>>t2.sec;
	swap(t1,t2);
	cout<<"after swapping"<<endl;
	cout<<"t1 value"<<t1.hrs<<t1.min<<t1.sec<<endl;
	cout<<"t2 value"<<t2.hrs<<t2.min<<t2.sec<<endl;
	return 0;
}
void swap(time& t1,time& t2)
{
	time temp;
	temp=t1;
	t1=t2;
	t2=temp;
}
