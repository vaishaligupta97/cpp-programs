#include<iostream>
using namespace std;

int main()
{
	char emp;
	enum etype {labourer,secretry,manager,accountant,executive,researcher};
	cout<<"enter employee type(only the first letter)"<<endl;
	cin>>emp;
	switch(emp)
	{
		case 'l':cout<<"labourer"<<endl;
					break;
		case 's':cout<<"secretry"<<endl;
					break;
		case 'm':cout<<"manager"<<endl;
					break;
		case 'a':cout<<"accountant"<<endl;
					break;
		case 'e':cout<<"executive"<<endl;
					break;
		case 'r':cout<<"researcher"<<endl;
					break;
	}
	return 0;
}
