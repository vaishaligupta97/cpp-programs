#include<iostream>
using namespace std;

struct time
{
	int hrs,min,sec;
};

int main()
{
	time t1;char ch;
	cout<<"enter the value of time (in the format 12:59:59)"<<endl;
	cin>>t1.hrs>>ch>>t1.min>>ch>>t1.sec;
	if(t1.hrs>12 || t1.min>59|| t1.sec>59)
	{
		cout<<"invalid value"<<endl;
	}
	else
	{
		long total_sec=t1.hrs*3600+t1.min*60+t1.sec;
		cout<<"total number of seconds "<<total_sec<<endl;
	}
	return 0;
}

