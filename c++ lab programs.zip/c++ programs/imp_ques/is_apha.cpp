#include<iostream>
#include<string.h>
using namespace std;

int main()
{	
/*	char c;
	int flag=0;
	cout<<"enter c"<<endl;
	cin>>c;
	if(isalpha(c)==0)
	{
		flag=1;
	}
	cout<<flag;*/
	int flag=0;
	int a;
	cout<<"enter a"<<endl;
	cin>>a;
	if(isalpha(a)==0)
	{
		flag=1;
	}
	cout<<flag;
}
