#include<iostream>
#include<string.h>
using namespace std;

class strin
{
	private:
		char str[10];
		int length;
	public:
		strin()
		{
		}
	/*	strin(char s[10],int n)
		{
			str=s;
			length=n;
		}*/
		void get()
		{
			cout<<"Enter string"<<endl;
			cin>>str;
		}
/*		void cal()
		{
			length=strlen(str);
		}
		void output()
		{
			cout<<str<<endl;
			cout<<length<<endl;
		}*/
/*		void operator ==(strin s)
		{
			int flag=0;
			length=strlen(str);
			cout<<length<<endl;
			s.length=strlen(s.str);
			cout<<s.length;
			if(length==s.length)
			{
				int i=0;
				while(str[i]!='\0')
				{
					if(str[i]!=s.str[i])
					{
						flag=1;
						break;
					}
					i++;
				}
				if(flag==1)
				{
					cout<<"strings are not equal"<<endl;
				}
				else
				{
					cout<<"strings are equal"<<endl;
				}
			}
			else
					cout<<"strings are not equal"<<endl;
		
		}*/
		void operator <(strin s)
		{
		int flag=0;
			length=strlen(str);
			cout<<length<<endl;
			s.length=strlen(s.str);
			cout<<s.length;
	//		if(length<s.length)
	//		{
				int i=0;
				while(str[i]!='\0')
				{
					if(str[i]>s.str[i])
					{
						flag=1;
						break;
					}
					i++;
				}
				if(flag==1)
				{
					cout<<"string1 is greater than string2"<<endl;
				}
				else
				{
					cout<<"string2 is greater than string1"<<endl;
				}
	//		}
	//		else
	//				cout<<"string1 is greater than string2"<<endl;
		
		}
};
int main()
{
	strin s1,s2;
	s1.get();
	s2.get();
//	s1==s2;
	s1<s2;
//	s1.get();
//	s1.cal();
//	s1.output();
	return 0;
}
