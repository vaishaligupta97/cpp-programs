#include<iostream>
using namespace std;
int main()
{
	int i,j;
	for(i=1;i<=20;i++)
	{
		for(j=1;j<=39;j++)
		{
			if(j>=(21-i) && j<=(19+i))
				cout<<"x";
			else
				cout<<" ";
		}
		cout<<endl;
	}
	return 0;
}
