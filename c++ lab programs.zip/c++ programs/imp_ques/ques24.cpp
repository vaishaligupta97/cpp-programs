#include<iostream>
using namespace std;
struct fraction
{
	int num;
	int deno;
};
int main()
{
	fraction f1,f2,f3;
	char ch;
	cout<<"enter first fraction"<<endl;
	cin>>f1.num>>ch>>f1.deno;
	cout<<"enter second fraction"<<endl;
	cin>>f2.num>>ch>>f2.deno;
	f3.num=f1.num*f2.deno +f2.num*f1.deno;
	f3.deno=f1.deno*f2.deno;
	cout<<"sum of fraction= "<<f3.num<<"/"<<f3.deno<<endl;
	return 0;
}
