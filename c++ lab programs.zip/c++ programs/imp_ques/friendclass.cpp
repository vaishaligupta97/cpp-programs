#include<iostream>
using namespace std;

class alpha
{
	private:
		int data1;
		char name[10];
	public:
		alpha(){
			data1=99;
			name="vaishali";
		}
		friend class beta; 		
};
class beta
{
	public:
		void func1(alpha a)		//access private alpha data
		{
			cout<<"data1 "<<a.data1<<endl;    //member function of beta can access the private data members of alpha
		}
		void func2(alpha a)
		{
			cout<<"data1 "<<a.data1<<endl;
		}
};

int main()
{
	alpha a;
	beta b;
	b.func1(a);
	b.func2(a);
	return 0;
}
