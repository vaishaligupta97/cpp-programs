#include<iostream>
using namespace std;
int main()
{
	const int i=10;
	cout<<i<<endl;
	int a=i;
	a+=10;
	cout<<a<<endl;
	a--;
	cout<<a<<endl;
	return 0;
}
