#include<iostream>
using namespace std;

double power(double n,int p);
int power(int n,int p);

int main()
{
	double n1;
	int p,n2;
	cout<<"enter the value of n1"<<endl;
	cin>>n1;
	cout<<"enter the value of n2"<<endl;
	cin>>n2;
	cout<<"enter the value of p"<<endl;
	cin>>p;
	double ans=power(n1,p);
	cout<<"ans= "<<ans<<endl;
	double ans2= power(n2,p);
	cout<<"ans2= "<<ans2;
	return 0;
}
double power(double n,int p)
{
	int i=1;
	double ans=1;
	while(i<=p)
	{
		ans=ans*n;
		i++;
	}
	return ans;
}
int power(int n,int p)
{
	int i=1;
	int ans=1;
	while(i<=p)
	{
		ans=ans*n;
		i++;
	}
	return ans;
}
