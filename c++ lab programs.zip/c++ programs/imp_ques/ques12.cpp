#include<iostream>
using namespace std;
int main()
{
	int num1,num2;
	char ch,op;
	do
	{
		cout<<"Enter first number operator and second number"<<endl;
		cin>>num1>>op>>num2;
		switch(op)
		{
			case '+':cout<<"sum= "<<num1+num2;
						break;
			case '-':cout<<"sub= "<<num1-num2;
						break;
			case '*':cout<<"mul= "<<num1*num2;
						break;
			case '/':cout<<"div= "<<num1/num2;
		}
		cout<<"\nDo you want to continue(y/n)"<<endl;
		cin>>ch;
	}while(ch!='n');
	return 0;
}
