#include<iostream>
#include<string.h>
using namespace std;

class strin
{
	private:
		char *str;
		int len;
	public:
		strin(char* s)
		{
			len=strlen(s);
			str=new char[len+1];
		}
		void putstring()
		{
			cout<<str;
		}
};
int main()
{
	strin s1("jamia");
	s1.putstring();
	return 0;
}
