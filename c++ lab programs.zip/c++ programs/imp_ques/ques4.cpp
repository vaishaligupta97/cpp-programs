#include<iostream>
using namespace std;
int main()
{
	cout<<"candy is dandy,"<<endl
	<<"but liquor is quicker"<<endl;
	return 0;
}
