#include<iostream>
using namespace std;

struct phone
{
	int areacode;
	int exchange;
	int number;
};
int main()
{
	phone p1,p2;
	p1={212,767,8900};
	cout<<"enter your area code,exchange and number"<<endl;
	cin>>p2.areacode>>p2.exchange>>p2.number;
	cout<<"my number is "<<'('<<p1.areacode<<") "<<p1.exchange<<'-'<<p1.number<<endl;
	cout<<"your number is "<<'('<<p2.areacode<<") "<<p2.exchange<<'-'<<p2.number<<endl;
	return 0;
}
