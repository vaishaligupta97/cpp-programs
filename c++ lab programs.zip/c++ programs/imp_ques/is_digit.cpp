#include<iostream>
#include<string.h>
using namespace std;

int main()
{	
//	char c;
	int flag=0;
	cout<<"enter c"<<endl;
//	cin>>c;
//	if(isdigit(c)==0)
//	{
//		flag=1;
//	}
//	cout<<flag;
	int a;
	cin>>a;
	if(isdigit(a)==0)
	{
		flag=1;
	}
	cout<<flag;
}
