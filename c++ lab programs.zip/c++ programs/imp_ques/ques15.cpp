#include<iostream>
using namespace std;
int main()
{
	char ch,op1,op;
	int a,b,c,d;
	do
	{
		cout<<"enter first fraction"<<endl;
		cin>>a>>op1>>b;
		cout<<"enter operation"<<endl;
		cin>>op;
		cout<<"Enter second fraction"<<endl;
		cin>>c>>op1>>d;
		switch(op)
		{
			case '+':cout<<a*d+b*c<<'/'<<b*d;
						break;
			case '-':cout<<a*d-b*c<<'/'<<b*d;
						break;
			case '*':cout<<(a*c)<<'/'<<(b*d);
						break;
			case '/':cout<<(a*d)<<'/'<<(b*c);
						break;
		}
		cout<<"\nDo you want to continue(y/n)"<<endl;
		cin>>ch;
	}while(ch!='n');
	return 0;
}
