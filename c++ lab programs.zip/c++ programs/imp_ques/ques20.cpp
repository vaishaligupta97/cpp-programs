#include<iostream>
using namespace std;

struct employee
{
	int emp_no;
	float salary;
};
int main()
{
	employee emp[3];
	for(int i=0;i<3;i++)
	{
		cout<<"enter employee "<<i+1<<" information"<<endl;
		cin>>emp[i].emp_no;
		cin>>emp[i].salary;
	}
	cout<<"entered employee information"<<endl;
	cout<<"emp_id"<<"\t"<<"salary"<<endl;
	for(int i=0;i<3;i++)
	{
		cout<<emp[i].emp_no<<"\t "<<emp[i].salary<<endl;
	}
	return 0;
}
