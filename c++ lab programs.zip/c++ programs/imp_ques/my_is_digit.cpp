#include<iostream>
using namespace std;

bool is_digit(int num)
{
	while(num!=0)
	{
		int d=num%10;
		if(d<0 || d>9 || 'a-z' ||'A-Z' ||".")
			return false;
		num=num/10;
	}
	return true;
}
int main()
{
	int a;
	cout<<"Enter a value"<<endl;
	cin>>a;
	int flag=0;
	if(is_digit(a)==false)
	{
		flag=1;
	}
	cout<<flag<<endl;
}
