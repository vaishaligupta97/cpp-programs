#include<iostream>
using namespace std;

struct time
{
	int hrs,min,sec;
};

long time_to_sec(time);
time sec_to_time(long);

int main()
{
	time t1,t2,t3;
	cout<<"enter the value of t1"<<endl;
	cin>>t1.hrs>>t1.min>>t1.sec;
	cout<<"enter the value of t2"<<endl;
	cin>>t2.hrs>>t2.min>>t2.sec;
	long t1_total_sec=time_to_sec(t1);
	long t2_total_sec=time_to_sec(t2);
	long total_sec=t1_total_sec + t2_total_sec;
	t3=sec_to_time(total_sec);
	cout<<"new time value "<<t3.hrs<<"-"<<t3.min<<"-"<<t3.sec<<endl;
	return 0;
}
long time_to_sec(time t)
{
	return t.hrs*3600+t.min*60+t.sec;
}
time sec_to_time(long total_sec)
{
	time t;
	t.hrs=total_sec/3600;
	t.min=(total_sec%3600)/60;
	t.sec=(total_sec%3600)%60;
	return t;
}
