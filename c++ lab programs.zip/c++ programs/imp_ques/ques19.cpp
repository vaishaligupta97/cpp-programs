#include<iostream>
using namespace std;

struct Distance
{
	int feet;
	float inches;
};

struct volume
{
	Distance length,width,height;
};
int main()
{
	volume v1={{3,7.5},{5,2.7},{4,6.8}};
	float length=v1.length.feet+v1.length.inches/12;
	float  width=v1.width.feet+v1.width.inches/12;
	float height=v1.height.feet+v1.height.inches/12;
	float vol=length*width*height;
	cout<<"volume is "<<vol<<endl;
	return 0;
}

