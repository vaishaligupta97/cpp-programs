#include<iostream>
using namespace std;
int main()
{

enum suit{clubs=1,diamond,heart,spades};
suit s=heart;
cout<<s+1<<endl; //output will be 4

enum direction{north,south,east,west};
direction dir=east;
cout<<"dir="<<dir; //output will be 2
return 0;
}

