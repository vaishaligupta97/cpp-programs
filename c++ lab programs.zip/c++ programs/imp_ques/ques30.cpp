#include<iostream>
using namespace std;
double power(double n,int p=2);

int main()
{
	double n,ans1,ans2;
	int p;
	cout<<"enter the value of n"<<endl;
	cin>>n;
	cout<<"enter the value of p"<<endl;
	cin>>p;
	ans1=power(n,p);
	cout<<"ans1= "<<ans1;
	ans2=power(n);
	cout<<"ans2= "<<ans2;
	return 0;
}
double power(double n,int p)
{
	int i=1,ans=1;
	while(i<=p)
	{
		ans=ans*n;
		i++;
	}
	return ans;
}
