#include<iostream>
using namespace std;

struct date
{ 
	int day,month,year;
};

int main()
{
	date d1;
	cout<<"enter a date in the format(dd/mm/yyyy)"<<endl;
	cin>>d1.day>>d1.month>>d1.year;
	if(d1.month>12 || d1.day>31)
	{
		cout<<"not a valid date"<<endl;
	}
	else
	{
		cout<<d1.day<<"/"<<d1.month<<"/"<<d1.year;
	}
	return 0;
}
