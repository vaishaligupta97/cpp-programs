#include<iostream>
using namespace std;

struct fraction
{
	int num,deno;
};

int main()
{
	fraction f1,f2,f3;int choice;char ch;
	do{
	cout<<"enter first fraction"<<endl;
	cin>>f1.num>>f1.deno;
	cout<<"enter second fraction"<<endl;
	cin>>f2.num>>f2.deno;
	cout<<"which operation u want to perform"<<endl;
	cout<<"case 1:addition"<<endl;
	cout<<"case 2:subtraction"<<endl;
	cout<<"case 3:multiplication"<<endl;
	cout<<"case 4:divison"<<endl;
	cin>>choice;
	switch(choice)
	{
		case 1:f3.num=f1.num*f2.deno+f2.num*f1.deno;
				f3.deno=f1.deno*f2.deno;
				cout<<"sum of f1 and f2 is "<<f3.num<<"/"<<f3.deno<<endl;
				break;
		case 2:f3.num=f1.num*f2.deno-f2.num*f1.deno;
				f3.deno=f1.deno*f2.deno;
				cout<<"subtraction of f1 and f2 is "<<f3.num<<"/"<<f3.deno<<endl;
				break;
		case 3:	f3.num=f1.num*f2.num;
				f3.deno=f1.deno*f2.deno;
				cout<<"multiplication of f1 and f2 is "<<f3.num<<"/"<<f3.deno<<endl;
				break;
		case 4:f3.num=f1.num*f2.deno;
				f3.deno=f1.deno*f2.num;
				cout<<"divison of f1 and f2 is "<<f3.num<<"/"<<f3.deno<<endl;
				break;
	}
	cout<<"do you want to continue(y/n)"<<endl;
	cin>>ch;
}while(ch!='n');
return 0;
}
